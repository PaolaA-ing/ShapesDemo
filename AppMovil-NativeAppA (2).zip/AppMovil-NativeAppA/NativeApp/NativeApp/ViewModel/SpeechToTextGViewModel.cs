﻿using NativeApp.Interfaces;
using NativeApp.Model;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Windows.Input;
using Xamarin.Forms;

namespace NativeApp.ViewModel
{
    public class SpeechToTextGViewModel : BaseViewModel
    {
        #region Commands
        public ICommand VozCommand { get; set; }
        #endregion

        #region Propiedades
        private ISpeechToText _speechRecongnitionInstance;

        private string _texto;
        public string Texto
        {
            get { return _texto; }
            set
            {
                _texto = value;
                OnPropertyChanged();
            }
        }
        #endregion

        #region Constructor
        public SpeechToTextGViewModel()
        {
            VozCommand = new Command(VozATextoGoogle);
        }
       
        #endregion
        public void Iniciar()
        {
            try
            {
                _speechRecongnitionInstance = DependencyService.Get<ISpeechToText>();
            }
            catch (Exception ex)
            {;
                Texto = ex.Message;
                
            }
            MessagingCenter.Subscribe<ISpeechToText, string>(this, "STT", (sender, args) =>
            {
                SpeechToTextFinalResultRecieved(args);
            });

            MessagingCenter.Subscribe<ISpeechToText>(this, "Final", (sender) =>
            {
                //Voz.IsEnabled = true;

            });

            MessagingCenter.Subscribe<IMessageSender, string>(this, "STT", (sender, args) =>
            {
                SpeechToTextFinalResultRecieved(args);
            });
        }

        private void SpeechToTextFinalResultRecieved(string args)
        {
            Texto = args;
           
        }

        private void VozATextoGoogle()
        {
            if (Device.RuntimePlatform == Device.Android)
            {
                try
                {
                    _speechRecongnitionInstance.StartSpeechToText();
                }
                catch (Exception ex)
                {
                    Debug.WriteLine(ex.Message);

                }
            }           

            else // iOS
            {
                //start.IsEnabled = false;
            }
        }
    }
}
