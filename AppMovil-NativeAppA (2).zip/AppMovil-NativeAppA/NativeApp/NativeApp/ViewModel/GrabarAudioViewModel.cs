﻿using NativeApp.Interfaces;
using Plugin.AudioRecorder;
using Plugin.Permissions;
using Plugin.Permissions.Abstractions;
using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Input;
using Xamarin.Forms;

namespace NativeApp.ViewModel
{
    public class GrabarAudioViewModel : BaseViewModel
    {
        #region Atributos        
        public Color BtnRecordColor { get; set; } = Color.FromHex("#7cbb45");
        public Color BtnStopColor { get; set; } = Color.FromHex("#7cbb45");
        public Color BtnPlayColor { get; set; } = Color.FromHex("#7cbb45");
        #endregion

        #region Propiedades
        bool _isEnableBtnStop;
        public bool IsEnableBtnStop
        {
            get => _isEnableBtnStop;
            set => SetProperty(ref _isEnableBtnStop, value);
        }
        bool _isEnableBtnPlay;
        public bool IsEnableBtnPlay
        {
            get => _isEnableBtnPlay;
            set => SetProperty(ref _isEnableBtnPlay, value);
        }

        bool _isEnableRecord;
        public bool IsEnableRecord
        {
            get => _isEnableRecord;
            set => SetProperty(ref _isEnableRecord, value);
        }

        bool _isSilence;
        public bool IsSilence
        {
            get { return _isSilence; }
            set { _isSilence = true; }
        }

        #endregion

        #region Commands
        public ICommand GrabarCommand { get; set; }
        public ICommand PausaCommand { get; set; }
        public ICommand PlayCommand { get; set; }

        #endregion

        #region Variables

        AudioRecorderService recorder;
        AudioPlayer player;
        bool isTimerRunning = false;
        int seconds = 0, minutes = 0;

        #endregion

        #region Propiedades

        private string _timerMin = "";
        public string TimerMin
        {
            get { return _timerMin; }
            set { _timerMin = value; OnPropertyChanged(); }
        }
        private string _timerSeg = "";
        public string TimerSeg
        {
            get { return _timerSeg; }

            set { _timerSeg = value; OnPropertyChanged(); }
        }
        #endregion
        #region Constructor
        public GrabarAudioViewModel()
        {
            GrabarCommand = new Command(GrabarAudio);
            PausaCommand = new Command(PausaAudio);
            PlayCommand = new Command(PlayAudio);

            recorder = new AudioRecorderService
            {
                StopRecordingAfterTimeout = true,
                TotalAudioTimeout = TimeSpan.FromSeconds(15),
                AudioSilenceTimeout = TimeSpan.FromSeconds(2)
            };
            player = new AudioPlayer();
            player.FinishedPlaying += Finish_Playing;
        }

        #endregion


        #region Metodos
        

        private void Finish_Playing(object sender, EventArgs e)
        {
            IsEnableRecord = true;
            IsEnableBtnPlay = true;
            IsEnableBtnStop = false;
            TimerSeg = "00";
            TimerMin = "00";
        }

        private async void GrabarAudio()
        {
            var status = await CrossPermissions.Current.CheckPermissionStatusAsync<MicrophonePermission>();
            if (status != PermissionStatus.Granted)
            {
                if (await CrossPermissions.Current.ShouldShowRequestPermissionRationaleAsync(Permission.Microphone))
                {
                    await Application.Current.MainPage.DisplayAlert("Micrófono", "Se deben conceder los permisos para poder grabar audio", "Aceptar");
                }

                status = await CrossPermissions.Current.RequestPermissionAsync <MicrophonePermission>();
            }

            if (status == PermissionStatus.Granted)
            {
                
                    if (!recorder.IsRecording)
                    {
                        seconds = 0;
                        minutes = 0;
                        isTimerRunning = true;
                        Device.StartTimer(TimeSpan.FromSeconds(1), () =>
                        {
                            seconds++;

                            if (seconds.ToString().Length == 1)
                            {
                                TimerSeg = "0" + seconds.ToString();
                            }
                            else
                            {
                                TimerSeg = seconds.ToString();
                            }
                            if (seconds == 60)
                            {
                                minutes++;
                                seconds = 0;

                                if (minutes.ToString().Length == 1)
                                {
                                    TimerMin = "0" + minutes.ToString();
                                }
                                else
                                {
                                    TimerMin = minutes.ToString();
                                }

                                TimerSeg = "00";
                            }
                            return isTimerRunning;
                        });

                        //
                        recorder.StopRecordingOnSilence = IsSilence;
                        var audioRecordTask = await recorder.StartRecording();

                        IsEnableRecord = false;
                        IsEnableBtnPlay = false;
                        IsEnableBtnStop = true;


                        await audioRecordTask;
                    }               
            }
            else if (status != PermissionStatus.Unknown)
            {
                Device.BeginInvokeOnMainThread(async () =>
                {
                    await Application.Current.MainPage.DisplayAlert("Atención", "Permisos de micrófono no concedido", "Aceptar");

                });
            }
            

        }

        private async void PausaAudio()
        {
            StopRecording();
            await recorder.StopRecording();
        }

        private void StopRecording()
        {
            isTimerRunning = false;
            IsEnableRecord = true;
            IsEnableBtnPlay = true;
            IsEnableBtnStop = false;
            TimerSeg = "00";
            TimerMin = "00";
        }

        private void PlayAudio()
        {
            try
            {
                var filePath = recorder.GetAudioFilePath();

                if (filePath != null)
                {
                    StopRecording();
                    player.Play(filePath);
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }
        #endregion

    }
}
