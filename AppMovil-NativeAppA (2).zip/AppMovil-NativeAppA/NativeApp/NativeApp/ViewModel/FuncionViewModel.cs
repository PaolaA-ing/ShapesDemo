﻿using iText.IO.Image;
using iText.Kernel.Events;
using iText.Kernel.Font;
using iText.Kernel.Geom;
using iText.Kernel.Pdf;
using iText.Kernel.Pdf.Canvas;
using iText.Layout;
using iText.Layout.Element;
using NativeApp.Interfaces;
using NativeApp.Model;
using NativeApp.Pages;
using NativeApp.Utils;
using Org.BouncyCastle.Asn1.Cms;
using Plugin.Barcode;
using Plugin.FilePicker;
using Plugin.FilePicker.Abstractions;
using Plugin.Fingerprint;
using Plugin.Fingerprint.Abstractions;
using Plugin.Media;
using Plugin.Media.Abstractions;
using Plugin.Permissions;
using Plugin.Permissions.Abstractions;
using System;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;
using IArchivo = NativeApp.Interfaces.IArchivo;
using Image = iText.Layout.Element.Image;
using PermissionStatus = Plugin.Permissions.Abstractions.PermissionStatus;

namespace NativeApp.ViewModel
{
    public class FuncionViewModel : BaseViewModel
    {
        #region Commands
        public ICommand GeoCommand { get; set; }
        public ICommand CargueCommand { get; set; }
        public ICommand SonidoCommand { get; set; }
        public ICommand AbrirFirmaCommand { get; set; }
        public ICommand BorrarFirmaCommand { get; set; }
        public ICommand AdjuntarCommand { get; set; }
        public ICommand BorrarAdjuntoCommand { get; set; }
        public ICommand AbrirAdjuntoCommand { get; set; }
        public ICommand CompartirCommand { get; set; }
        public ICommand CompartirArchivoCommand { get; set; }
        public ICommand VibracionCommand { get; set; }
        public ICommand InfoCommand { get; set; }
        public ICommand VozCommand { get; set; }
        public ICommand LeerCodigoCommand { get; set; }
        public ICommand TomarFotoCommand { get; set; }
        public ICommand BorrarFotoCommand { get; set; }
        public ICommand BorrarArchivoCommand { get; set; }
        public ICommand ConvertirCommand { get; set; }
        public ICommand BorrarPdfCommand { get; set; }
        public ICommand AudioCommand { get; set; }
        public ICommand PruebaCommand { get; set; }
        public ICommand HuellaCommand { get; set; }
        public ICommand GrabarCommand { get; set; }
        public ICommand AudioGoogleCommand { get; set; }
        #endregion

        #region Variables
        int exactitud = (int)GeolocationAccuracy.Default; //Depende del nivel de exactitud que se desee
        string ubicacionAct;
        string noDisponible = "No Disponible";
        const string RESOURCES_RAW = "NativeApp.Resources.Raw";
        public const string TITULO_FIRMA = "Firma";
        string titulo;
        private string _modelo = string.Empty;
        private string _fabricante = string.Empty;
        private string _nombreDispositivo = string.Empty;
        private string _versionSistOperativo = string.Empty;
        private object _tipo = null;
        #endregion

        #region Propiedades     
        private string _codigo = "";
        public string Codigo
        {
            get { return _codigo; }
            set
            {
                _codigo = value;
                OnPropertyChanged();
            }
        }

        private string _archivoAdj = "";
        public string ArchivoAdj
        {
            get { return _archivoAdj; }
            set
            {
                _archivoAdj = value;
                OnPropertyChanged();
            }
        }

        private string _nombreAdj = "";
        public string NombreAdj
        {
            get { return _nombreAdj; }
            set
            {
                _nombreAdj = value;
                OnPropertyChanged();
            }
        }       

        public int Exactitud
        {
            get => exactitud;
            set => SetProperty(ref exactitud, value);
        }
        public string UbicacionAct
        {
            get => ubicacionAct;
            set => SetProperty(ref ubicacionAct, value);
        }

        private Coordenadas _infoCoord = new Coordenadas();
        public Coordenadas InfoCoord
        {
            get { return _infoCoord; }
            set
            {
                _infoCoord = value;
                OnPropertyChanged();
            }
        }

        private Firma _firmaObject = new Firma();
        private ImageSource _archivoFoto;

        public ImageSource ArchivoFoto
        {
            get => _archivoFoto;
            set => SetProperty(ref _archivoFoto, value);
            
        }
        public Firma FirmaObject
        {
            get { return _firmaObject; }
            set
            {
                _firmaObject = value;
                OnPropertyChanged();
            }
        }


        public string Titulo
        {
            get => titulo;
            set => SetProperty(ref titulo, value);
        }
        public string Modelo
        {
            get { return _modelo; }
            set { _modelo = value;
                OnPropertyChanged();
            }
        }
        public string Fabricante
        {
            get { return _fabricante; }
            set {
                _fabricante = value;
                OnPropertyChanged(); }
        }

        public string NombreDispositivo
        {
            get { return _nombreDispositivo; }
            set
            {
                _nombreDispositivo = value;
                OnPropertyChanged();
            }
        }
        public string VersionSistOperativo
        {
            get { return _versionSistOperativo; }
            set
            {
                _versionSistOperativo = value;
                OnPropertyChanged();
            }
        }
        public object Tipo
        {
            get { return _tipo; }
            set
            {
                _tipo = value;
                OnPropertyChanged();
            }
        }

        public ImageSource ImgFirma
        {
            get
            {
                ImageSource retSource = null;
                if (FirmaObject.FirmaBase64 != null)
                {
                    byte[] imageAsBytes = System.Convert.FromBase64String((string)FirmaObject.FirmaBase64);
                    retSource = ImageSource.FromStream(() => new MemoryStream(imageAsBytes));
                }
                return retSource;
            }
        }

        public ImageSource Source { get; private set; }

        #endregion

        #region Constructor
        public FuncionViewModel()
        {
            
            
            BorrarArchivoCommand = new Command(BorrarArchivo);
           
            //Firma
            AbrirFirmaCommand = new Command(AbrirFirma);
            BorrarFirmaCommand = new Command(BorrarFirma);
            //Compartir
            CompartirCommand = new Command<string>(Compartir);
            CompartirArchivoCommand = new Command(CompartirArchivos);
            //Vibracion
            //VibracionCommand = new Command<string>(Vibracion);
            //Info dispositivo
            InfoCommand = new Command(InformacionDispositivo);
            //Texto a voz
            VozCommand = new Command(AbrirTextoaVoz);
            //Lector de codigo
            //LeerCodigoCommand = new Command(EscanearCodigo);
            //Foto
            //TomarFotoCommand = new Command (TomarFoto);
           
            //Audio a texto
            AudioCommand = new Command(AbrirAudioaTexto);
            AudioGoogleCommand = new Command(AbrirAudioaTextoGoogle);
          
            //Grabar audio
            GrabarCommand = new Command(GrabarAudio);
        }


        #endregion

        #region Metodos
        public void Iniciar()
        {
            OnPropertyChanged("ImgFirma");
            OnPropertyChanged("FirmaObject");
        }
        
        public async void BorrarFoto()
        {
            try
            {
                IsVisFoto = true;
                if(ArchivoFoto != null)
                {
                    bool action = await Application.Current.MainPage.DisplayAlert("Foto", "¿Desea eliminar la foto?", "Sí", "No");
                    if (action)
                    {
                       ArchivoFoto = null;
                        IsVisFoto = false;
                    }
                }
            }
            catch (Exception e)
            {
                Debug.Write(e.Message);
            }
        }
        



        private async Task AbrirPdf(string rutaPDF)
        {            
            var status = await CrossPermissions.Current.CheckPermissionStatusAsync<StoragePermission>();
            if (status != PermissionStatus.Granted)
            {
                if (await CrossPermissions.Current.ShouldShowRequestPermissionRationaleAsync(Permission.Storage))
                {
                    await Application.Current.MainPage.DisplayAlert("Almacenamiento", "Se deben conceder los permisos para poder acceder abrir el PDF", "Aceptar");
                }

                status = await CrossPermissions.Current.RequestPermissionAsync<StoragePermission>();
            }

            if (status == PermissionStatus.Granted)
            {
                if (!string.IsNullOrWhiteSpace(rutaPDF))
                {
                    DependencyService.Get<IArchivo>().AbrirDesdeLocal(rutaPDF);
                }
            }
            else if (status != PermissionStatus.Unknown)
            {                
                Device.BeginInvokeOnMainThread(async () =>
                {
                    await Application.Current.MainPage.DisplayAlert("Atención", "Permisos de almacenamiento local de archivos no concedidos", "Aceptar");
                   
                });
            }
        }

      

       

        public void InformacionDispositivo()
        {
            IsVisInfor = false;
            try
            {
                Modelo = DeviceInfo.Model;
                Fabricante = DeviceInfo.Manufacturer;
                NombreDispositivo = DeviceInfo.Name;
                VersionSistOperativo = DeviceInfo.VersionString;
                Tipo = DeviceInfo.DeviceType;

                IsVisInfor = true;
            }
            catch (Exception ex)
            {
                Debug.WriteLine(ex.Message);
            }

        }

        
       

        private async void CompartirArchivos()
        {
            try
            {
                var fn = "Adjunto.txt";
                var file = System.IO.Path.Combine(FileSystem.CacheDirectory, fn);
                File.WriteAllText(file, "Documento prueba");

                await Share.RequestAsync(new ShareFileRequest
                {
                    File = new ShareFile(file),
                    PresentationSourceBounds = Device.RuntimePlatform == Device.iOS && Device.Idiom == TargetIdiom.Phone
                                           ? new System.Drawing.Rectangle(0, 20, 0, 0)
                                           : System.Drawing.Rectangle.Empty
                });
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
            }
        }

        public async void Compartir(string text)
        {
            try
            {
                await Share.RequestAsync(new ShareTextRequest
                {
                    Text = text,
                    Title = "Compartir texto"
                });

            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
            }
        }

       
        public async void BorrarArchivo()
        {
            IsVisAdj = true;
            bool action = await Application.Current.MainPage.DisplayAlert("Adjunto", $"Desea eliminar el archivo \"{NombreAdj}\"?", "Sí", "No");
            if (action)
            {
                try
                {       
                    //Depende de la BD que se maneje en el proyecto
                    ArchivoAdj = null;
                    NombreAdj = null;
                    IsVisAdj = false;
                }
                catch (Exception e)
                {
                    Debug.Write(e.Message);
                }
            }
        }
       private void AbrirTextoaVoz()
       {
            try
            {
                Navigation.PushAsync(new TextoVozPage());
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
            }
        }

        private void AbrirAudioaTexto()
        {
            try
            {
                Navigation.PushAsync(new AudioTextoPage());
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
            }
        }

        private void AbrirAudioaTextoGoogle()
        {
            try
            {
                Navigation.PushAsync(new SpeechToTextGPage());
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
            }
        }
        private void GrabarAudio()
        {
            try
            {
                Navigation.PushAsync(new GrabarAudioPage());
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
            }
        }
        //private void AbrirAgregarUsu()
        //{
        //    try
        //    {
        //        Navigation.PushAsync(new AgregarUsuPage());
        //    }
        //    catch (Exception e)
        //    {
        //        Debug.WriteLine(e.Message);
        //    }
        //}
        private void AbrirFirma()
        {
            IsVisFirma = false;
            try
            {
                Navigation.PushAsync(new FirmaPage(FirmaObject));
                IsVisFirma = true;
            }
            catch (Exception e)
            {
                Debug.WriteLine(e.Message);
            }
        }
        
        private void BorrarFirma()
        {
            Device.BeginInvokeOnMainThread(async () =>
            {
                bool action = await Application.Current.MainPage.DisplayAlert("Atención", "¿Desea borrar la firma?", "Sí", "No");

                if (!action)
                    return;

                FirmaObject.FirmaBase64 = null;
                IsVisFirma = false;
                OnPropertyChanged("FirmaObject");
                OnPropertyChanged("ImgFirma");
            });
        }


          
       
        
        #endregion

    }
        
    }
