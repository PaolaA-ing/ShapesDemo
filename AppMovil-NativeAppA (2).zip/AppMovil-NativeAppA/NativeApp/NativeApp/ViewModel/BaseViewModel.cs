﻿using NativeApp.Helpers;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Text;
using Xamarin.Forms;

namespace NativeApp.ViewModel
{
    public class BaseViewModel : ObservableObject, INotifyPropertyChanged
    {
        #region Atributos
        public INavigation Navigation { get; set; }
        #endregion

        #region Propiedades

        //ActivityIndicator
        bool isRunGeo;
        public bool IsRunGeo
        {
            get => isRunGeo;
            set => SetProperty(ref isRunGeo, value, onChanged: () => OnPropertyChanged(nameof(NoRunGeo)));
        }
        public bool NoRunGeo => !IsRunGeo;

        bool isRunPdf;
        public bool IsRunPdf
        {
            get => isRunPdf;
            set => SetProperty(ref isRunPdf, value, onChanged: () => OnPropertyChanged(nameof(NoRunPdf)));
        }
        public bool NoRunPdf => !IsRunPdf;

        private bool _isRunFoto = false;
        public bool IsRunFoto
        {
            get { return _isRunFoto; }
            set
            {
                _isRunFoto = value;
                OnPropertyChanged();
            }
        }

        private bool _isRunArch = false;
        public bool IsRunArch
        {
            get { return _isRunArch; }
            set
            {
                _isRunArch = value;
                OnPropertyChanged();
            }
        }

        bool _isVisGeo;
        public bool IsVisGeo
        {
            get => _isVisGeo;
            set => SetProperty(ref _isVisGeo, value);
        }

        bool _isVisCodigo;
        public bool IsVisCodigo
        {
            get => _isVisCodigo;
            set => SetProperty(ref _isVisCodigo, value);
        }

        bool _isVisBorrar;
        public bool IsVisBorrar
        {
            get => _isVisBorrar;
            set => SetProperty(ref _isVisBorrar, value);
        }

        bool _isVisFoto;
        public bool IsVisFoto
        {
            get => _isVisFoto;
            set => SetProperty(ref _isVisFoto, value);
        }

        bool _isVisInfor;
        public bool IsVisInfor
        {
            get => _isVisInfor;
            set => SetProperty(ref _isVisInfor, value);
        }


        bool _isVisFirma;
        public bool IsVisFirma
        {
            get => _isVisFirma;
            set => SetProperty(ref _isVisFirma, value);
        }

        bool _isVisAdj;
        public bool IsVisAdj
        {
            get => _isVisAdj;
            set => SetProperty(ref _isVisAdj, value);
        }
        #endregion
    }

}

