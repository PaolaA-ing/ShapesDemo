﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Windows.Input;
using Xamarin.Essentials;
using Xamarin.Forms;

namespace NativeApp.ViewModel
{
    public class TextoVozViewModel: BaseViewModel
    {
        #region Commands
        public ICommand VozCommand { get; set; }
        #endregion


        private string _textovoz;
        public string TextoVoz
        {
            get => _textovoz;
            set
            {
                _textovoz = value;
                OnPropertyChanged();
            }
        }

        #region Constructor
        public TextoVozViewModel()
        {
           
        }
        #endregion

       
        

    }
}
