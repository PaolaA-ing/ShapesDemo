﻿using NativeApp.Model;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Input;
using Xamarin.Forms;

namespace NativeApp.ViewModel
{
    public class FirmaViewModel : BaseViewModel
    {
        #region Propiedades

        public Func<Task<byte[]>> SignatureFromStream { get; set; }
        public byte[] Signature { get; set; }
        private Firma _firmaObject = new Firma();

        public Firma FirmaObject
        {
            get { return _firmaObject; }
            set
            {
                _firmaObject = value;
                OnPropertyChanged();
            }
        }

        #endregion

        #region Commands

        public ICommand FirmaCommand => new Command(async () =>
        {
        try
        {
            Signature = await SignatureFromStream();
            if (Signature != null)
            {
                FirmaObject.FirmaBase64 = Convert.ToBase64String(Signature);
               

                string mensaje = "Recuerde que se encuentra estampando su firma.\n\nElimine la firma se desea realizar cambios";
                await Application.Current.MainPage.DisplayAlert("Atención", mensaje, "Cerrar");

                await Navigation.PopAsync();
            }
            else
            {
                await Application.Current.MainPage.DisplayAlert("Atención", "Por favor, ingrese la firma", "Cerrar");
            }
        }
            catch (Exception e)
            {
                Debug.Write(e.Message);
            }
        });
        #endregion
        public FirmaViewModel(Firma firma)
        {
            FirmaObject = firma;
        }
    }
}
