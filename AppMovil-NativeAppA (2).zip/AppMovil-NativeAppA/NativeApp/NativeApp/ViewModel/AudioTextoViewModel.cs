﻿using Microsoft.CognitiveServices.Speech;
using NativeApp.Interfaces;
using NativeApp.Utils;
using System;
using System.Windows.Input;
using Xamarin.Forms;

namespace NativeApp.ViewModel
{
    public class AudioTextoViewModel : BaseViewModel
    {
        SpeechRecognizer recognizer;
        IMicrophoneService micService;
        

        #region Propiedades 
        private string _transcribedtext = "";
        public string Transcribedtext
        {
            get { return _transcribedtext; }
            set
            {
                _transcribedtext = value;
                OnPropertyChanged();
            }
        }

        private bool _isTranscribing = false;
        public bool IsTranscribing
        {
            get { return _isTranscribing; }
            set
            {
                _isTranscribing = value;
                OnPropertyChanged();
            }
        }
        #endregion

        #region Commands
        public ICommand TranscribedCommand { get; set; }
        #endregion
        public AudioTextoViewModel()
        {
            TranscribedCommand = new Command(TranscribirTexto);
        }

        public void Iniciar()
        {
           micService = DependencyService.Resolve<IMicrophoneService>();
        }


        private async void TranscribirTexto()
        {
            bool isMicEnabled = await micService.GetPermissionAsync();

            
            if (!isMicEnabled)
            {
                UpdateTranscription("Por favor, conceda acceso al micrófono!");
                return;
            }

            if (recognizer == null)
            {
                ///TODO para poder utilizar esta funcionalidad se requiere un licenciamiento en Azure.
                //var config = SpeechConfig.FromSubscription(Constants.CognitiveServicesApiKey, Constants.CognitiveServicesRegion);

                //config.SetProperty(PropertyId.Speech_LogFilename, "Android/data/ApplicationName/logfile.txt");               

                var sourceLanguageConfig = SourceLanguageConfig.FromLanguage("es-CO");
                //recognizer = new SpeechRecognizer(config, sourceLanguageConfig);
                
                recognizer.Recognized += (obj, args) =>
                {
                    UpdateTranscription(args.Result.Text);
                };
            }

            // Si ya está transcribiendo, detener el reconocedor de voz
            if (IsTranscribing)
            {
                try
                {
                    await recognizer.StopContinuousRecognitionAsync();
                }
                catch (Exception ex)
                {
                    UpdateTranscription(ex.Message);
                }
                IsTranscribing = false;
            }

            // Si no está transcribiedo, inicie el reconocedor de voz
            else
            {
                Device.BeginInvokeOnMainThread(() =>
                {
                    InsertDateTimeRecord();
                });
                try
                {
                    await recognizer.StartContinuousRecognitionAsync();
                }
                catch (Exception ex)
                {
                    UpdateTranscription(ex.Message);
                }
                IsTranscribing = true;
            }
        
        }       

        private void InsertDateTimeRecord()
        {
            var msg = $"=================\n{DateTime.Now.ToString()}\n=================";
            UpdateTranscription(msg);
        }

        private void UpdateTranscription(string newText)
        {
            Device.BeginInvokeOnMainThread(() =>
            {
                if (!string.IsNullOrWhiteSpace(newText))
                {
                    Transcribedtext += $"{newText}\n";
                }
            });
        }
    }
}
