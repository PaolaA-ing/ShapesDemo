﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Text;

namespace NativeApp.Utils
{
    public  class Util
    {
        public static string GetFechaArchivo()
        {
            return DateTime.Now.ToString("yyyyMMddHHmmss");
        }

        public static string GetMegabytesFormat(long value)
        {
            try
            {
                return string.Format(CultureInfo.InvariantCulture, "{0:#.00", ConvertBytesToMegabytes(value)); 
            }
            catch (Exception e)
            {
                Debug.Write(e.Message);
            }
            return string.Empty;
        }

        public static double ConvertBytesToMegabytes(long bytes)
        {
            return (bytes / 1024f) / 1024F;
        }
    }
}
