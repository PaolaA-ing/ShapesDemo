﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NativeApp.Interfaces
{
    public interface IAssetService
    {
        string GetAssetPath(string filename);
    }
}
