﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NativeApp.Interfaces
{
    public interface ISpeechToText
    {
        void StartSpeechToText();
        void StopSpeechToText();
    }
}
