﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NativeApp.Model
{
    public class Coordenadas
    {
        public double Latitud { get; set; }
        public double Longitud { get; set; }
        public double? Exactitud { get; set; }
        public double? Altitud { get; set; }
        public double? Velocidad { get; set; }
        public DateTimeOffset Fecha { get; set; }
        public DateTimeOffset Hora { get; set; }
    }
}
