﻿using SQLite;
using System;
using System.Collections.Generic;
using System.Text;

namespace NativeApp.Model
{
    public class FotoAdjunta
    {
        [PrimaryKey, AutoIncrement]
        public int Id { get; set; }
        public string Foto { get; set; }
        public string nomb_foto { get; set; }
        public DateTime FechaRegistro { get; set; }
        public bool IsBorrarEnabled => !string.IsNullOrWhiteSpace(Foto);

    }
}
