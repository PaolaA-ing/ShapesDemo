﻿using System;
using System.Collections.Generic;
using System.Text;

namespace NativeApp.Model
{
    public class Firma
    {
        public string FirmaBase64 { get; set; }
        public string Titulo { get; set; }
        public string Nombre { get; set; }
        public string TipoDoc { get; set; }
        public string Documento { get; set; }
        public string Cargo { get; set; }

    }
}
