﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Globalization;
using System.Text;
using Xamarin.Forms;

namespace NativeApp.Converters
{
    public class FillToBoolConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            bool fillToVisible = true;
            try
            {
                try
                {
                    if (parameter != null)
                        fillToVisible = !((string)parameter).Trim().ToLower().Equals("false");
                }
                catch (Exception e)
                {
                    Debug.Write(e.Message);
                }
                if (value == null)
                {
                    return !fillToVisible;
                }
                else if (value.GetType() == typeof(DateTime))
                {
                    return fillToVisible;
                }
                else if (value.GetType() == typeof(string))
                {
                    return fillToVisible != string.IsNullOrWhiteSpace((string)value);
                }
            }
            catch (Exception e)
            {
                Debug.Write(e.Message);
            }
            return true;
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
