﻿using NativeApp.Model;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Text;
using Xamarin.Forms;

namespace NativeApp.Converters
{
    public class AdjuntoToImageConverter : IValueConverter
    {
        public object Convert (object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            ImageSource retSource = null;
            if (value == null)
                return retSource;

            try
            {
                string nombreImagen = ((FotoAdjunta)value).nomb_foto;

                if (nombreImagen == null)
                    return "";

                if (nombreImagen.ToLower().EndsWith(".png") || nombreImagen.ToLower().EndsWith(".jpg"))
                {
                    byte[] imageAsBytes = System.Convert.FromBase64String(((FotoAdjunta)value).Foto);
                    retSource = ImageSource.FromStream(() => new MemoryStream(imageAsBytes));
                }
                else
                {
                    retSource = "ic_adjunto.png";
                }
            }
            catch (Exception e)
            {
                Debug.Write(e.Message);
            }

            return retSource;
        }
        public object ConvertBack(object value, Type targetType, object parameter, System.Globalization.CultureInfo culture)
        {
            throw new NotImplementedException();
        }
    }
}
