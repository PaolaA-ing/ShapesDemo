﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Xamarin.Forms;

namespace NativeApp.Behaviors
{
    public class ViewTappedButtonBehavior : Behavior <View>
    {
        protected override void OnAttachedTo(View bindable)
        {
            var exists = bindable.GestureRecognizers.FirstOrDefault() as TapGestureRecognizer;

            if (exists != null)
                exists.Tapped += View_Tapped;

            base.OnAttachedTo(bindable);
        }

        protected override void OnDetachingFrom(View bindable)
        {
            var exists = bindable.GestureRecognizers.FirstOrDefault() as TapGestureRecognizer;

            if (exists != null)
                exists.Tapped -= View_Tapped;

            base.OnDetachingFrom(bindable);
        }

        bool _isAnimating = false;
        private void View_Tapped(object sender, EventArgs e)
        {
            if (_isAnimating)
                return;

            _isAnimating = true;

            var view = (View)sender;

            Device.BeginInvokeOnMainThread(() =>
            {
                try
                {
                    Color oldColor = default(Color);
                    var labelView = sender as Label;

                    if (labelView != null)
                    {
                        labelView.TextColor = oldColor;
                    }
                }
                finally
                {
                    _isAnimating = false;
                }
            });
        }
    }
}
