﻿using NativeApp.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace NativeApp.Pages
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class SpeechToTextGPage : ContentPage
    {
        SpeechToTextGViewModel vm;
        public SpeechToTextGPage()
        {
            InitializeComponent();
            vm = new SpeechToTextGViewModel();
            BindingContext = vm;
            vm.Navigation = this.Navigation;
        }
        protected override void OnAppearing()
        {
            base.OnAppearing();
            ((SpeechToTextGViewModel)BindingContext).Iniciar();
        }
    }
}