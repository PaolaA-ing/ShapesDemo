﻿using Microsoft.CognitiveServices.Speech;
using NativeApp.Interfaces;
using NativeApp.Utils;
using NativeApp.ViewModel;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using Xamarin.Forms;
using Xamarin.Forms.Xaml;

namespace NativeApp.Pages
{
    [XamlCompilation(XamlCompilationOptions.Compile)]
    public partial class AudioTextoPage : ContentPage
    {
        AudioTextoViewModel vm;

        public AudioTextoPage()
        {
            InitializeComponent();
            vm = new AudioTextoViewModel();
            BindingContext = vm;
            vm.Navigation = this.Navigation;               
        }

        protected override void OnAppearing()
        {
            base.OnAppearing();
            ((AudioTextoViewModel)BindingContext).Iniciar();
        }
        //private void UpdateDisplayState()
         //{
             //Device.BeginInvokeOnMainThread(() =>
             //{
                 //if (isTranscribing)
                 //{
                     //transcribeButton.Text = "Stop";
                     //transcribeButton.BackgroundColor = Color.Red;
                     //transcribingIndicator.IsRunning = true;
                 //}
                 //else
                 //{
                   //  transcribeButton.Text = "Transcribe";
                     //transcribeButton.BackgroundColor = Color.Green;
                     //transcribingIndicator.IsRunning = false;
                 //}
             //});
         //}

      
    }
}