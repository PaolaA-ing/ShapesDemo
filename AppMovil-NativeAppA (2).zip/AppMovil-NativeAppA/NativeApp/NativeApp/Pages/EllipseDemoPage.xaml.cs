﻿using Xamarin.Forms;

namespace NativeApp.Pages
{
    public partial class EllipseDemoPage : ContentPage
    {
        public EllipseDemoPage()
        {
            InitializeComponent();
        }
    }
}
