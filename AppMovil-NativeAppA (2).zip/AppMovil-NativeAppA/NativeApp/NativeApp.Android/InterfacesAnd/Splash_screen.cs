﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Android.Animation;
using Android.App;
using Android.Content;
using Android.Content.PM;
using Android.OS;
using Android.Runtime;
using Android.Views;
using Android.Widget;
using Com.Airbnb.Lottie;

namespace NativeApp.Droid.ConexInterf
{
    [Activity(Theme = "@style/Theme.Splash", MainLauncher = true, NoHistory = true, ConfigurationChanges = ConfigChanges.ScreenSize | ConfigChanges.Orientation, ScreenOrientation = ScreenOrientation.Portrait)]
    public class Splash_screen : Activity, Animator.IAnimatorListener
    {
        protected override void OnCreate(Bundle savedInstanceState)
        {
            base.OnCreate(savedInstanceState);
            System.Threading.Thread.Sleep(0);
            SetContentView(Resource.Layout.Activity_splash);

            //El activity_splash debe ponerse como Android Resource
            var animationView = FindViewById<LottieAnimationView>(Resource.Id.animation_view);
            animationView.AddAnimatorListener(this);
            animationView.SetMinAndMaxProgress(0f, 0.4f);
            
        }
        public void OnAnimationCancel(Animator animation)
        {
            Console.Write("OnAnimationCancel");
        }

        public void OnAnimationEnd(Animator animation)
        {
            StartActivity(new Intent(Application.Context, typeof(MainActivity)));
        }

        public void OnAnimationRepeat(Animator animation)
        {
            Console.Write("OnAnimationRepeat");
        }

        public void OnAnimationStart(Animator animation)
        {
            Console.Write("OnAnimationStart");
        }
    }
}