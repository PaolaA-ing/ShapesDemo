﻿using System;
using System.IO;
using Android.Content;
using NativeApp.Interfaces;
using Xamarin.Forms;

[assembly: Dependency(typeof(NativeApp.Droid.ArchivoAndroid))]
namespace NativeApp.Droid
{
    public class ArchivoAndroid : IArchivo
    {
        public bool AbrirDesdeLocal(string rutaArchivo)
        {
            Java.IO.File file = new Java.IO.File(rutaArchivo);
            file.SetReadable(true);
            return AbrirArchivo(Android.Net.Uri.FromFile(file), GetMimeType(rutaArchivo));
        }

        public bool AbrirArchivo(Android.Net.Uri uri, string mimeType)
        {
            Intent intent = new Intent(Intent.ActionView);
            intent.SetDataAndType(uri, mimeType);
            intent.SetFlags(ActivityFlags.ClearWhenTaskReset | ActivityFlags.NewTask | ActivityFlags.GrantReadUriPermission);

            try
            {
                Android.App.Application.Context.StartActivity(intent);
                return true;
            }
            catch (ActivityNotFoundException e)
            {
                Console.Write(e.Message);
            }
            return false;
        }

        public string GetMimeType(string nombreArchivo)
        {
            string application = string.Empty;
            try
            {
                string extension = Path.GetExtension(nombreArchivo);

                switch (extension.ToLower())
                {
                    case ".pdf":
                        application = "application/pdf";
                        break;                   
                    case ".jpg":
                    case ".jpeg":
                    case ".png":
                        application = "image/jpeg";
                        break;                    
                    default:
                        application = "*/*";
                        break;
                }
            }
            catch (Exception e)
            {                
                Console.Write(e.Message);
            }

           Console.Write($"MimeType: {application}");

            return application;
        }


    }
}